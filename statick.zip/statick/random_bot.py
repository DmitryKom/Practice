import wx  # Импорт библиотеки wxPython для создания графического интерфейса
import wx.grid as gridlib  # Импорт модуля для работы с сеткой в библиотеке wxPython
import random  # Импорт модуля random для генерации случайных чисел


class Board:
    def __init__(self):
        # Инициализация игровой доски размером 10x10 и инициализация списка кораблей
        self.size = 10
        self.board = [['' for _ in range(10)] for _ in range(10)]  # Создание пустой доски
        self.ships = {'Battleship': 4, 'Cruiser': 3, 'Destroyer': 2, 'Submarine': 1}  # Словарь типов кораблей и их размеров
        self.remaining_ships = self.size  # Количество оставшихся кораблей для размещения
        self.placing_ship = None  # Переменные для временного хранения информации о текущем размещаемом корабле
        self.placing_size = 0
        self.placing_orientation = None
        self.board_count = {ship: 0 for ship in self.ships}  # Словарь для подсчета количества размещенных кораблей каждого типа
        self.ship_counts = {'Battleship': 1, 'Cruiser': 2, 'Destroyer': 3, 'Submarine': 4}  # Максимальное количество кораблей каждого типа

    def place_ship(self, x, y):
        # Размещение корабля на указанных координатах
        if self.can_place_ship(x, y):
            self.set_ship(x, y, self.placing_size, self.placing_orientation, self.placing_ship)
            self.remaining_ships -= 1  # Уменьшение количества оставшихся кораблей
            self.board_count[self.placing_ship] += 1  # Обновление количества размещенных кораблей указанного типа
            return True
        else:
            return False

    def can_place_ship(self, x, y):
        # Проверка возможности размещения корабля на указанных координатах
        if self.placing_orientation == 'H' and x + self.placing_size > self.size:
            return False  # Если корабль выходит за границы доски по горизонтали, то размещение невозможно
        elif self.placing_orientation == 'V' and y + self.placing_size > self.size:
            return False  # Если корабль выходит за границы доски по вертикали, то размещение невозможно

        for i in range(-1, self.placing_size+1):
            for j in range(-1, 2):
                # Проверка на перекрытие с другими кораблями
                if self.placing_orientation == 'H':
                    if 0 <= y+j < self.size and 0 <= x+i < self.size and self.board[y+j][x+i] != '':
                        return False  # Если корабль перекрывается с другими кораблями, то размещение невозможно
                else:
                    if 0 <= y+i < self.size and 0 <= x+j < self.size and self.board[y+i][x+j] != '':
                        return False  # Если корабль перекрывается с другими кораблями, то размещение невозможно

        # Проверка на максимальное количество размещаемых кораблей каждого типа
        if self.placing_ship is not None:
            if self.board_count[self.placing_ship] >= self.ship_counts[self.placing_ship]:
                return False  # Если количество размещенных кораблей данного типа достигло максимума, то размещение невозможно

        return True  # Размещение возможно

    def set_ship(self, x, y, size, orientation, ship):
        # Установка корабля на доску в указанных координатах и ориентации
        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship  # Установка горизонтального корабля
            else:
                self.board[y + i][x] = ship  # Установка вертикального корабля

    def place_computer_ships(self):
        # Размещение кораблей компьютера на доске
        for ship, size in self.ships.items():
            while True:
                x, y, orientation = random.randint(0, 9), random.randint(0, 9), random.choice(['H', 'V'])
                self.placing_ship = ship
                self.placing_size = size
                self.placing_orientation = orientation
                if self.can_place_ship(x, y):
                    self.set_ship(x, y, size, orientation, ship)
                    break

    def check_hit(self, x, y):
        # Проверка попадания по указанным координатам
        if self.board[y][x] != '':
            self.board[y][x] = 'X'  # Помечаем попадание на доске
            return True  # Есть попадание
        return False  # Промах

    def check_win(self):
        # Проверка завершения игры
        for row in self.board:
            for cell in row:
                if cell != '' and cell != 'X':
                    return False  # Если есть незатронутые клетки, игра продолжается
        return True  # Все корабли потоплены, игра завершена

class BattleshipGame(wx.Frame):
    def __init__(self, parent):
        # Инициализация игрового окна
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="Морской бой")

        self.panel = wx.Panel(self)  # Создание панели для размещения элементов управления
        self.player_board = Board()  # Создание игровой доски для игрока
        self.computer_board = Board()  # Создание игровой доски для компьютера
        self.player_grid = self.create_grid(self.panel, self.player_board)  # Создание сетки для отображения игровой доски игрока
        self.computer_grid = self.create_grid(self.panel, self.computer_board)  # Создание сетки для отображения игровой доски компьютера

        # Создание боковой панели для размещения элементов управления
        self.side_panel = wx.Panel(self.panel)
        self.side_sizer = wx.BoxSizer(wx.VERTICAL)  # Создание вертикального контейнера для элементов управления на боковой панели
        self.side_panel.SetSizer(self.side_sizer)  # Установка контейнера для боковой панели

        # Создание элементов управления (выбор типа корабля, ориентация, кнопка начала игры)
        self.ship_choice = wx.Choice(self.side_panel, choices=list(self.player_board.ships.keys()))  # Выбор типа корабля
        self.orientation_checkbox = wx.CheckBox(self.side_panel, label="Горизонтально")  # Чекбокс для выбора ориентации корабля
        self.start_game_button = wx.Button(self.side_panel, label="Начать игру")  # Кнопка начала игры

        # Добавление элементов управления на боковую панель
        self.side_sizer.Add(self.ship_choice, 0, wx.ALL, 5)  # Добавление выбора типа корабля на боковую панель
        self.side_sizer.Add(self.orientation_checkbox, 0, wx.ALL, 5)  # Добавление чекбокса ориентации на боковую панель
        self.side_sizer.Add(self.start_game_button, 0, wx.ALL, 5)  # Добавление кнопки начала игры на боковую панель

        # Установка расположения элементов на главной панели
        sizer = wx.BoxSizer(wx.VERTICAL)  # Создание вертикального контейнера для размещения всех элементов на главной панели
        sizer.Add(self.player_grid, 1, wx.EXPAND)  # Добавление сетки игрока на главную панель
        sizer.Add(self.side_panel, 0, wx.EXPAND)  # Добавление боковой панели на главную панель
        sizer.Add(self.computer_grid, 1, wx.EXPAND)  # Добавление сетки компьютера на главную панель

        self.panel.SetSizerAndFit(sizer)  # Установка вертикального контейнера для главной панели
        self.Fit()  # Автоматическое изменение размера окна под размер содержимого

        # Привязка обработчиков событий к элементам управления
        self.ship_choice.Bind(wx.EVT_CHOICE, self.on_ship_choice)  # Привязка события выбора типа корабля к обработчику on_ship_choice
        self.orientation_checkbox.Bind(wx.EVT_CHECKBOX, self.on_orientation_checkbox)  # Привязка события изменения чекбокса ориентации к обработчику on_orientation_checkbox
        self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click)  # Привязка события клика по ячейке сетки игрока к обработчику on_cell_click     
        self.start_game_button.Bind(wx.EVT_BUTTON, self.on_start_game)  # Привязка события нажатия кнопки начала игры к обработчику on_start_game
        self.start_game_button.Disable()  # Отключение кнопки начала игры по умолчанию

        self.update_grids()  # Обновление отображения сеток для игрока и компьютера
        self.computer_board.place_computer_ships()  # Размещение кораблей компьютера на доске


        self.last_hit = None  # Последнее попадание компьютера
        self.game_started = False  # Флаг начала игры

    def create_grid(self, parent, board):
        # Создание сетки для отображения игровой доски
        grid = gridlib.Grid(parent)  # Создание сетки
        grid.CreateGrid(10, 10)  # Создание сетки размером 10x10

        for i in range(10):
            grid.SetRowLabelValue(i, str(i+1))  # Установка меток строк
            grid.SetColLabelValue(i, chr(65+i))  # Установка меток столбцов (буквенные обозначения)

        grid.AutoSizeColumns(False)  # Автоматическое изменение размеров колонок
        for col in range(10):
            grid.SetColSize(col, 30)  # Установка размеров столбцов
            grid.SetRowSize(col, 30)  # Установка размеров строк
        return grid  # Возвращаем созданную сетку


    def on_cell_click(self, event):
        if not self.player_board.remaining_ships > 1:
           self.start_game_button.Enable()  # Если все корабли игрока уже размещены, разрешаем начать игру
        # Обработчик клика мыши по ячейке сетки (размещение корабля)
        if not self.game_started and self.player_board.remaining_ships > 0:  # Если игра еще не начата и у игрока остались корабли для размещения
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты кликнутой ячейки
            print(row, col)
            if self.player_board.place_ship(col, row):  # Пытаемся разместить корабль в данной ячейке
                self.update_grids()  # Обновляем сетки после размещения корабля

    def on_cell_click_player(self, event):
        # Обработчик клика мыши по ячейке сетки (ход игрока)
        row, col = event.GetRow(), event.GetCol()  # Получаем координаты кликнутой ячейки
        if self.computer_grid.GetCellValue(row, col) != '':  # Если в выбранной ячейке уже есть результат атаки
            return  # Ничего не делаем
        if self.computer_board.check_hit(col, row):  # Проверяем, попал ли игрок в корабль компьютера
            self.computer_grid.SetCellValue(row, col, 'X')  # Помечаем попадание игрока на сетке компьютера
            if self.computer_board.check_win():  # Проверяем, выиграл ли игрок
                wx.MessageBox('Вы выиграли!', 'Поздравляем')  # Выводим сообщение о победе игрока
                self.Close()  # Закрываем приложение
        else:
            self.computer_grid.SetCellValue(row, col, 'O')  # Помечаем промах игрока на сетке компьютера
        self.computer_move()  # Ход компьютера
        self.update_grids()  # Обновляем сетки после каждого хода

    def computer_move(self):
        # Ход компьютера
        while True:  # Бесконечный цикл, пока компьютер не сделает ход
            if self.last_hit is not None:  # Если было попадание в предыдущем ходу
                # Попытка атаковать соседнюю клетку, если есть попадание
                directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Направления атаки (верх, право, низ, лево)
                random.shuffle(directions)  # Перемешиваем направления для рандомного выбора
                for dx, dy in directions:  # Перебираем все направления
                    row, col = self.last_hit[0] + dx, self.last_hit[1] + dy  # Вычисляем координаты клетки для атаки
                    if 0 <= row < 10 and 0 <= col < 10 and self.player_grid.GetCellValue(row, col) == '':  # Проверяем, что координаты находятся в пределах доски и клетка не была атакована
                        break  # Прекращаем перебор направлений, если нашли подходящую клетку
                else:
                    self.last_hit = None  # Если все соседние клетки были проверены и они все были атакованы, сбрасываем последнее попадание
            if self.last_hit is None:  # Если не было предыдущего попадания (или оно было сброшено)
                row, col = random.randint(0, 9), random.randint(0, 9)  # Выбираем случайную клетку для атаки
            if self.player_grid.GetCellValue(row, col) != '':  # Если выбранная клетка уже была атакована
                continue  # Пропускаем эту итерацию цикла и выбираем новую клетку
            if self.player_board.check_hit(col, row):  # Если атака попала в корабль игрока
                self.player_grid.SetCellValue(row, col, 'X')  # Помечаем попадание на сетке компьютера
                self.last_hit = (row, col)  # Запоминаем последнее попадание компьютера
                if self.player_board.check_win():  # Проверяем, выиграл ли компьютер
                    wx.MessageBox('Компьютер выиграл!', 'О нет!')  # Выводим сообщение о победе компьютера
                    self.Close()  # Закрываем приложение
                break  # Завершаем цикл хода компьютера, так как атака была успешной
            else:
                self.player_grid.SetCellValue(row, col, 'O')  # Помечаем промах на сетке компьютера
                break  # Завершаем цикл хода компьютера, так как атака была неудачной
        self.update_grids()  # Обновляем сетку после каждого хода компьютера

    def update_grids(self):
            # Обновление отображения сеток после каждого хода
            for i in range(10):
                for j in range(10):
                    if self.player_board.board[i][j] != '':
                        self.player_grid.SetCellBackgroundColour(i, j, wx.BLUE)  # Установка цвета клетки на сетке
            self.player_grid.ForceRefresh()  # Принудительное обновление отображения сетки

    def on_ship_choice(self, event):
        ship_name = self.ship_choice.GetString(self.ship_choice.GetSelection())  # Получение выбранного типа корабля
        
        # Проверка на максимальное количество размещаемых кораблей выбранного типа
        if self.player_board.board_count[ship_name] >= self.player_board.ships[ship_name]:
            wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
            return
        self.player_grid.Enable()  # Включение сетки для размещения корабля
        self.player_board.placing_ship = ship_name  # Установка типа корабля для размещения
        self.player_board.placing_size = self.player_board.ships[ship_name]  # Установка размера корабля для размещения

    def on_orientation_checkbox(self, event):
        # Обработчик выбора ориентации корабля
        self.player_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'  # Установка ориентации корабля (горизонтально или вертикально)


    def on_start_game(self, event):
        # Обработчик нажатия кнопки начала игры
        if self.player_board.remaining_ships == 0:  # Проверка, что все корабли игрока уже размещены
            self.game_started = True  # Установка флага начала игры
            self.update_grids()  # Обновление отображения сеток
            self.computer_move()  # Ход компьютера
            self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click_player, self.computer_grid)  # Привязка обработчика клика по клетке компьютера
            self.start_game_button.Disable()  # Отключение кнопки начала игры, чтобы нельзя было начать игру заново


app = wx.App(False)
frame = BattleshipGame(None)
frame.Show(True)
app.MainLoop()


