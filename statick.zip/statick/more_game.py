import wx  # Импортируем библиотеку wxPython для создания графического интерфейса
import wx.grid as gridlib  # Импортируем модуль для работы с сетками в wxPython
import wx.lib.dialogs  # Импортируем модуль для диалоговых окон в wxPython
import random  # Импортируем модуль для генерации случайных чисел
import os
import subprocess

class Board:
    def __init__(self, size, num_ships):
        self.size = size  # Инициализируем размер доски
        self.board = [['' for _ in range(size)] for _ in range(size)]  # Создаем двумерный массив для хранения состояния клеток на доске
        self.num_ships = num_ships  # Инициализируем количество кораблей
        self.ships = {'Battleship': 4, 'Cruiser': 3, 'Destroyer': 2, 'Submarine': 1}  # Определяем типы кораблей и их размеры
        self.remaining_ships = self.num_ships  # Определяем количество оставшихся кораблей для размещения
        self.placing_ship = None  # Инициализируем переменную для текущего размещаемого корабля
        self.placing_size = 0  # Инициализируем переменную для размера текущего размещаемого корабля
        self.placing_orientation = None  # Инициализируем переменную для ориентации текущего размещаемого корабля
        self.visible = True  # Инициализируем переменную, определяющую видимость доски
        self.mines = []  # Добавленный атрибут для хранения информации о минах
        self.board_count = {ship: 0 for ship in self.ships}  # Инициализируем словарь для подсчета размещенных кораблей каждого типа
        self.ship_counts = {'Battleship': 1, 'Cruiser': 2, 'Destroyer': 3, 'Submarine': 4}  # Определяем количество кораблей каждого типа
    
    def place_mines(self, num_mines):
        for _ in range(num_mines):  # Генерируем указанное количество мин
            x, y = random.randint(0, self.size-1), random.randint(0, self.size-1)  # Генерируем случайные координаты для размещения мины
            print(x, y)  # Выводим координаты мины (для тестирования)
            self.mines.append((x, y))  # Добавляем координаты мины в список мин на доске

    def place_ship(self, x, y):
        if self.can_place_ship(x, y):  # Проверяем, можно ли разместить корабль в указанных координатах
            self.set_ship(x, y, self.placing_size, self.placing_orientation, self.placing_ship)  # Размещаем корабль на доске
            self.remaining_ships -= 1  # Уменьшаем количество оставшихся кораблей для размещения
            self.board_count[self.placing_ship] += 1  # Обновляем количество размещенных кораблей
            return True  # Возвращаем True, если корабль успешно размещен
        else:
            return False  # Возвращаем False, если корабль не может быть размещен

    def can_place_ship(self, x, y):
        # Проверяем, не выходит ли корабль за границы доски
        if self.placing_orientation == 'H' and x + self.placing_size > self.size:
            return False  # Возвращаем False, если корабль выходит за границы доски при горизонтальной ориентации
        elif self.placing_orientation == 'V' and y + self.placing_size > self.size:
            return False  # Возвращаем False, если корабль выходит за границы доски при вертикальной ориентации


        # Проверяем, не перекрывается ли корабль с другими кораблями или выходит за границы доски
        for i in range(-1, self.placing_size+1):
            for j in range(-1, 2):
                if self.placing_orientation == 'H':
                    if 0 <= y+j < self.size and 0 <= x+i < self.size and self.board[y+j][x+i] != '':
                        return False  # Возвращаем False, если корабль перекрывается с другими кораблями или выходит за границы доски при горизонтальной ориентации
                else:
                    if 0 <= y+i < self.size and 0 <= x+j < self.size and self.board[y+i][x+j] != '':
                        return False  # Возвращаем False, если корабль перекрывается с другими кораблями или выходит за границы доски при вертикальной ориентации

        # Добавляем проверку на количество размещаемых кораблей каждого типа
        if self.placing_ship is not None:
            if self.board_count[self.placing_ship] >= self.ship_counts[self.placing_ship]:
                return False  # Возвращаем False, если достигнуто максимальное количество кораблей данного типа

        return True  # Возвращаем True, если корабль может быть успешно размещен


    def set_ship(self, x, y, size, orientation, ship):
        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship  # Размещаем корабль на доске горизонтально
            else:
                self.board[y + i][x] = ship  # Размещаем корабль на доске вертикально

    def check_hit(self, x, y):
        if self.board[y][x] != '':
            if self.board[y][x] == 'X':  # Уже подбитая клетка
                return False
            self.board[y][x] = 'X'  # Помечаем как подбитую
            # Проверяем, если корабль полностью подбит, помечаем его соответственно
            ship_destroyed = True
            for row in self.board:
                for cell in row:
                    if cell == self.board[y][x]:
                        ship_destroyed = False
                        break
            if ship_destroyed:
                for row in range(len(self.board)):
                    for col in range(len(self.board[row])):
                        if self.board[row][col] == self.board[y][x]:
                            self.board[row][col] = 'X'
            return True  # Возвращаем True, если успешно подбита клетка корабля
        return False  # Возвращаем False, если клетка пуста (промах)
    
    def check_win(self):
        for row in self.board:
            for cell in row:
                if cell != '' and cell != 'X':
                    return False  # Возвращаем False, если на доске есть неразрушенные корабли
        return True  # Возвращаем True, если все корабли разрушены


    def destroyed_ships(self):
        destroyed = {ship: 0 for ship in self.ships}  # Инициализируем словарь для подсчета разрушенных кораблей каждого типа
        for row in self.board:
            for cell in row:
                if cell == 'X':  # Если клетка подбита
                    for ship in self.ships:
                        if ship in cell:  # Проверяем, к какому кораблю относится подбитая клетка
                            destroyed[ship] += 1  # Увеличиваем количество разрушенных кораблей данного типа
        return destroyed  # Возвращаем словарь с количеством разрушенных кораблей каждого типа

class BattleshipGame(wx.Frame):
    def __init__(self, parent):
        
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="Морской бой", size=wx.DefaultSize, style = (wx.MINIMIZE_BOX | wx.CLOSE_BOX | wx.CAPTION))  # Инициализируем главное окно приложения с указанием заголовка и размера
        ico = wx.Icon('logo.ico', wx.BITMAP_TYPE_ICO)
        self.SetIcon(ico)
        self.Center()
        self.InitUI()
        self.panel = wx.Panel(self)  # Создаем панель для размещения виджетов

        self.status_bar = self.CreateStatusBar()  # Создание статус-бара
        self.board_size = self.get_board_size_dialog()  # Получаем размер доски от пользователя
        if self.board_size is None:
            self.Close()  # Закрываем окно, если не удалось получить корректный размер поля

        self.num_mines = self.get_mines_count_dialog()  # Получаем количество мин от пользователя
        self.num_ships = self.get_ships_count_dialog()  # Получаем количество кораблей от пользователя
        self.player1_board = Board(self.board_size, self.num_ships)  # Создаем игровую доску для первого игрока
        self.player2_board = Board(self.board_size, self.num_ships)  # Создаем игровую доску для второго игрока
        self.player1_grid = self.create_grid(self.panel, self.player1_board)  # Создаем сетку для отображения игровой доски первого игрока
        self.player2_grid = self.create_grid(self.panel, self.player2_board)  # Создаем сетку для отображения игровой доски второго игрока
        self.player1_grid.Disable()  # Отключаем сетку для первого игрока
        self.player2_grid.Disable()  # Отключаем сетку для второго игрока
        self.current_player = 1  # Устанавливаем текущего игрока

        self.player1_text = wx.StaticText(self.panel, label="")  # Создаем статический текст для первого игрока
        self.player2_text = wx.StaticText(self.panel, label="")  # Создаем статический текст для второго игрока

        self.side_panel = wx.Panel(self.panel)  # Создаем боковую панель для размещения виджетов
        self.side_sizer = wx.BoxSizer(wx.VERTICAL)  # Создаем вертикальный сизер для боковой панели
        self.side_panel.SetSizer(self.side_sizer)  # Устанавливаем сизер для боковой панели

        self.finish_placement_button = wx.Button(self.side_panel, label="Завершить размещение")  # Создаем кнопку для завершения размещения кораблей
        self.finish_placement_button.Disable()  # Отключаем кнопку
        self.start_game_button = wx.Button(self.side_panel, label="Начать игру")  # Создаем кнопку для начала игры
        self.start_game_button.Disable()  # Отключаем кнопку
        self.ship_choice = wx.Choice(self.side_panel, choices=list(self.player1_board.ships.keys()))  # Создаем выпадающий список для выбора типа корабля
        self.orientation_checkbox = wx.CheckBox(self.side_panel, label="Горизонтально")  # Создаем чекбокс для выбора ориентации корабля
        self.side_sizer.Add(self.ship_choice, 0, wx.ALL, 5)  # Добавляем выпадающий список выбора типа корабля на боковую панель
        self.side_sizer.Add(self.orientation_checkbox, 0, wx.ALL, 5)  # Добавляем чекбокс выбора ориентации корабля на боковую панель
        self.side_sizer.Add(self.finish_placement_button, 2, wx.ALL, 5)  # Добавляем кнопку завершения размещения на боковую панель с относительным размером 2
        self.side_sizer.Add(self.start_game_button, 0, wx.ALL, 5)  # Добавляем кнопку начала игры на боковую панель

        sizer = wx.BoxSizer(wx.HORIZONTAL)  # Создаем вертикальный сизер для компоновки виджетов на основной панели
        sizer.Add(self.player1_text, 0, wx.EXPAND)  # Добавляем статический текст для первого игрока на основную панель
        sizer.Add(self.player1_grid, 1, wx.EXPAND)  # Добавляем сетку для отображения игровой доски первого игрока на основную панель с расширением по вертикали
        sizer.Add(self.side_panel, 0, wx.EXPAND)  # Добавляем боковую панель на основную панель
        sizer.Add(self.player2_text, 0, wx.EXPAND)  # Добавляем статический текст для второго игрока на основную панель
        sizer.Add(self.player2_grid, 1, wx.EXPAND)  # Добавляем сетку для отображения игровой доски второго игрока на основную панель с расширением по вертикали
        self.finish_placement_button.SetMinSize((200, 30))  # Устанавливаем минимальный размер кнопки завершения размещения
        self.panel.SetSizerAndFit(sizer)  # Устанавливаем сизер для основной панели и автоматически подгоняем размер
        self.Fit()  # Подгоняем размер окна под размер содержимого

        self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, lambda event: self.on_cell_click(event, self.player1_grid, self.player2_grid))  # Привязываем обработчик события клика на клетку сетки для первого игрока
        self.finish_placement_button.Bind(wx.EVT_BUTTON, self.on_finish_placement)  # Привязываем обработчик кнопки завершения размещения
        self.start_game_button.Bind(wx.EVT_BUTTON, self.on_start_game)  # Привязываем обработчик кнопки начала игры
        self.ship_choice.Bind(wx.EVT_CHOICE, self.on_ship_choice)  # Привязываем обработчик выбора типа корабля
        self.orientation_checkbox.Bind(wx.EVT_CHECKBOX, self.on_orientation_checkbox)  # Привязываем обработчик чекбокса выбора ориентации корабля

        self.player1_board.place_mines(self.num_mines)  # Размещаем мины на доске первого игрока
        self.player2_board.place_mines(self.num_mines)  # Размещаем мины на доске второго игрока
        self.update_grids()  # Обновляем сетки

        self.game_started = False  # Устанавливаем флаг начала игры в False

    def InitUI(self):
        menubar = wx.MenuBar()
        fileMenu = wx.Menu()
        aboutMenu = wx.Menu()

        inMenu = fileMenu.Append(wx.ID_ANY, 'В меню')
        #fileMenu.Append(wx.ID_ANY, 'Выбор режима', 'Выбор режима')
        fileMenu.Append(wx.ID_EXIT, 'Выйти')

        menubar.Append(fileMenu, 'Menu')
        menubar.Append(aboutMenu, 'About')

        Aboutcreator = aboutMenu.Append(wx.ID_ANY, "О разработчике", "Информация о разработчике")
        Aboutgame = aboutMenu.Append(wx.ID_ANY, "Правила игры", "Правила игры")



        # Обработчики событий
        self.SetMenuBar(menubar)
        self.Bind(wx.EVT_MENU, self.OnAboutcreator, Aboutcreator)
        self.Bind(wx.EVT_MENU, self.HelpGame, Aboutgame)
        self.Bind(wx.EVT_MENU, self.sea_battle_panel, inMenu)
        self.Bind(wx.EVT_MENU, self.onQuit, id=wx.ID_EXIT)

    def onQuit(self, event):
        self.Close()

    def OnAboutcreator(self, event):
        aboutDlg = wx.MessageDialog(self, "Данную игру разработал студент 2 курса группы 5.205-2\nКомягин Дмитрий Алексеевич", "О разработчике", wx.OK)
        aboutDlg.ShowModal()

    def HelpGame(self, event):
        aboutDlg = wx.MessageDialog(self, "Игра для двух участников, в которой игроки по очереди делают 'выстрелы'. \nЕсли у врага с этими координатами имеется корабль, то корабль или его палуба (дека)\n убивается, попавший делает еще один ход. Цель игрока: первым убить все игровые\n корабли врага партии.", "Правила игры", wx.OK)
        aboutDlg.ShowModal()

    def sea_battle_panel(self, event):
    # Очистить панель перед отображением сетки игры
        self.Close()

        # Путь к вашему модулю
        module_path = 'D:\\Дима Основное\\Загрузки\\statick\\sea_battle_panel.py'

        # Проверяем, существует ли файл
        if os.path.exists(module_path):
            # Запускаем модуль с помощью subprocess
            subprocess.Popen(['python', module_path])
        else:
            print(f"Модуль {module_path} не найден.")

    def update_status_bar(self, message):
        self.status_bar.SetStatusText(message)  # Обновляем текст в статус-баре
    def get_ships_count_dialog(self):
        # Создаем диалоговое окно для ввода количества кораблей
        dlg = wx.TextEntryDialog(self.panel, 'Введите количество кораблей (от 1 до 10):', 'Количество кораблей', '10')
        # Если пользователь нажал "ОК"
        if dlg.ShowModal() == wx.ID_OK:
            ships_text = dlg.GetValue()  # Получаем введенное количество кораблей
            try:
                ships = int(ships_text)  # Преобразуем введенное значение в целое число
                if 1 <= ships <= 10:  # Проверяем, находится ли введенное значение в допустимом диапазоне
                    return ships  # Возвращаем количество кораблей
                else:
                    wx.MessageBox('Некорректное количество кораблей. Введите число от 1 до 10.', 'Ошибка', wx.OK | wx.ICON_ERROR)
                    return self.get_ships_count_dialog()  # Рекурсивно вызываем диалоговое окно для повторного ввода
            except ValueError:
                wx.MessageBox('Некорректное количество кораблей. Введите число от 1 до 10.', 'Ошибка', wx.OK | wx.ICON_ERROR)
                return self.get_ships_count_dialog()  # Рекурсивно вызываем диалоговое окно для повторного ввода
        else:
            self.Close()  # Закрываем окно, если пользователь нажал "Отмена"

    def get_mines_count_dialog(self):
        # Создаем диалоговое окно для ввода количества мин
        dlg = wx.TextEntryDialog(self.panel, 'Введите количество мин (должно быть четным):', 'Количество мин', '10')
        # Если пользователь нажал "ОК"
        if dlg.ShowModal() == wx.ID_OK:
            mines_text = dlg.GetValue()  # Получаем введенное количество мин
            try:
                mines = int(mines_text)  # Преобразуем введенное значение в целое число
                if mines % 2 == 0 and mines > 0:  # Проверяем, является ли введенное значение четным положительным числом
                    return mines  # Возвращаем количество мин
                else:
                    wx.MessageBox('Некорректное количество мин. Введите четное положительное число.', 'Ошибка', wx.OK | wx.ICON_ERROR)
                    self.get_mines_count_dialog()  # Повторно вызываем диалоговое окно для повторного ввода
            except ValueError:
                wx.MessageBox('Некорректное количество мин. Введите четное положительное число.', 'Ошибка', wx.OK | wx.ICON_ERROR)
                self.get_mines_count_dialog()  # Повторно вызываем диалоговое окно для повторного ввода
        else:
            self.Close()  # Закрываем окно, если пользователь нажал "Отмена"

    def get_board_size_dialog(self):
        # Создаем диалоговое окно для ввода размера поля
        dlg = wx.TextEntryDialog(self.panel, 'Введите размер поля (от 1 до 26):', 'Размер поля', '10')
        # Если пользователь нажал "ОК"
        if dlg.ShowModal() == wx.ID_OK:
            size_text = dlg.GetValue()  # Получаем введенный размер поля
            try:
                size = int(size_text)  # Преобразуем введенное значение в целое число
                if 1 <= size <= 26:  # Проверяем, находится ли введенное значение в допустимом диапазоне
                    return size  # Возвращаем размер поля
                else:
                    wx.MessageBox('Некорректный размер поля. Введите число от 1 до 26.', 'Ошибка', wx.OK | wx.ICON_ERROR)
            except ValueError:
                wx.MessageBox('Некорректный размер поля. Введите число от 1 до 26.', 'Ошибка', wx.OK | wx.ICON_ERROR)
        return None  # Возвращаем None, если пользователь нажал "Отмена"

    def create_grid(self, parent, board):
        # Создаем сетку для отображения игровой доски
        grid = gridlib.Grid(parent)
        grid.CreateGrid(self.board_size, self.board_size)  # Устанавливаем размер сетки

        # Устанавливаем метки строк и столбцов
        for i in range(self.board_size):
            grid.SetRowLabelValue(i, str(i+1))
            grid.SetColLabelValue(i, chr(65+i))

        grid.AutoSizeColumns(False)  # Автоматически подгоняем размер столбцов
        # Устанавливаем размеры столбцов и строк
        for col in range(self.board_size):
            grid.SetColSize(col, 30)
            grid.SetRowSize(col, 30)
        grid.EnableEditing(False)  # Отключить редактирование ячеек
        grid.EnableDragGridSize(False)  # Отключить изменение размеров сетки методом перетаскивания
        grid.EnableDragColMove(False)  # Отключить перетаскивание столбцов
        grid.EnableDragColSize(False)  # Отключить изменение размеров столбцов методом перетаскивания
        grid.EnableDragRowSize(False)  # Отключить изменение размеров строк методом перетаскивания
        grid.EnableDragGridSize(False)
        return grid  # Возвращаем созданную сетку

    def on_orientation_checkbox(self, event):
        # Обработчик события изменения состояния чекбокса ориентации корабля
        # Устанавливаем ориентацию размещения кораблей в соответствии с выбором пользователя
        self.player1_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'

    def on_cell_click(self, event, grid1, grid2):
        # Обработчик события клика по клетке сетки
        if not self.player1_board.remaining_ships > 1:
            self.finish_placement_button.Enable()  # Включаем кнопку завершения размещения, если корабли размещены

        # Проверяем, что игра не началась и текущий игрок - первый, и остались неразмещенные корабли
        if not self.game_started and self.current_player == 1 and self.player1_board.remaining_ships > 0:
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика
            if self.player1_board.place_ship(col, row):  # Пытаемся разместить корабль
                self.update_grids()  # Обновляем сетки
                ship_size = self.player1_board.placing_size  # Получаем размер размещаемого корабля
                # Отображаем размещаемый корабль на сетке
                self.player1_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'
                if self.player1_board.placing_orientation == 'H':
                    for i in range(ship_size):
                        self.player1_grid.SetCellBackgroundColour(row, col + i, wx.BLUE)
                        self.player1_grid.Refresh()

                else:
                    for i in range(ship_size):
                        self.player1_grid.SetCellBackgroundColour(row + i, col, wx.BLUE)
                        self.player1_grid.Refresh()
        
            if self.player1_board.remaining_ships < 1:
                # Если все корабли размещены, отображаем их на сетке и включаем кнопку завершения размещения
                self.finish_placement_button.Enable()
                for row in range(grid1.GetNumberRows()):
                    self.player1_grid.Refresh()
                    for col in range(grid1.GetNumberCols()):
                        self.player1_grid.SetCellBackgroundColour(row, col, wx.WHITE)
                        self.player1_grid.Refresh()
                self.update_grids()

        # Проверяем, что игра не началась и текущий игрок - второй, и остались неразмещенные корабли
        elif not self.game_started and self.current_player == 2 and self.player2_board.remaining_ships > 0:
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика
            if self.player2_board.place_ship(col, row):  # Пытаемся разместить корабль
                self.update_grids()  # Обновляем сетки
                ship_size = self.player2_board.placing_size  # Получаем размер размещаемого корабля
                # Отображаем размещаемый корабль на сетке
                self.player2_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'
                if self.player2_board.placing_orientation == 'H':
                    for i in range(ship_size):
                        self.player2_grid.SetCellBackgroundColour(row, col + i, wx.BLUE)
                        self.player2_grid.Refresh()
                else:
                    for i in range(ship_size):
                        self.player2_grid.SetCellBackgroundColour(row + i, col, wx.BLUE)
                        self.player2_grid.Refresh()
                        
            if self.player2_board.remaining_ships < 1:
                # Если все корабли размещены, отображаем их на сетке и включаем кнопку завершения размещения
                self.finish_placement_button.Enable()
                for row in range(grid2.GetNumberRows()):
                    self.player2_grid.Refresh()
                    for col in range(grid2.GetNumberCols()):
                        self.player2_grid.SetCellBackgroundColour(row, col, wx.WHITE)
                        self.player2_grid.Refresh()
                self.update_grids()

    def on_finish_placement(self, event):
        # Обработчик события завершения размещения кораблей
        if not self.game_started:  # Проверяем, что игра еще не началась
            self.player1_board.visible = False  # Скрываем доски игроков
            self.player2_board.visible = False
            if self.current_player == 1:  # Если текущий игрок - первый
                self.current_player = 2  # Переключаем на второго игрока
                self.finish_placement_button.SetLabel("Завершить размещение (Игрок 2)")  # Изменяем надпись на кнопке для второго игрока
                self.update_grids()  # Обновляем сетки
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.start_game_button.Enable()  # Включаем кнопку начала игры

    def on_start_game(self, event):
        # Обработчик события начала игры
        if not self.game_started:  # Проверяем, что игра еще не началась
            self.game_started = True  # Устанавливаем флаг начала игры в True
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения
            self.start_game_button.Disable()  # Отключаем кнопку начала игры
            self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click_game)  # Привязываем обработчик клика на клетку для игрового режима
            self.update_status_bar("Игра началась")  # Обновляем статус игры

    def on_ship_choice(self, event):
        # Обработчик выбора типа корабля
        ship_name = self.ship_choice.GetString(self.ship_choice.GetSelection())  # Получаем выбранный тип корабля
        if self.current_player == 1:  # Если текущий игрок - первый
            if self.player1_board.board_count[ship_name] >= self.player1_board.ships[ship_name]:
                # Проверяем, что не превышено максимальное количество кораблей данного типа
                wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
                return
            self.player1_grid.Enable()  # Включаем сетку для размещения корабля
            self.player1_board.placing_ship = ship_name  # Устанавливаем тип размещаемого корабля
            self.player1_board.placing_size = self.player1_board.ships[ship_name]  # Устанавливаем размер корабля
        elif self.current_player == 2:  # Если текущий игрок - второй
            if self.player2_board.board_count[ship_name] >= self.player2_board.ships[ship_name]:
                # Проверяем, что не превышено максимальное количество кораблей данного типа
                wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
                return
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения для второго игрока
            self.player2_grid.Enable()  # Включаем сетку для размещения корабля
            self.player2_board.placing_ship = ship_name  # Устанавливаем тип размещаемого корабля
            self.player2_board.placing_size = self.player2_board.ships[ship_name]  # Устанавливаем размер корабля

    def on_cell_click_game(self, event):
        # Обработчик события клика на клетку во время игрового режима
        if self.game_started:  # Проверяем, что игра началась
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика
            # Проверяем, не попадает ли клик на мину
            if (row, col) in self.player1_board.mines or (row, col) in self.player2_board.mines:
                self.explode_mine(row, col)  # Обработка взрыва мины
                return

            if self.current_player == 1:  # Если текущий игрок - первый
                self.update_status_bar("Ходит игрок 1")  # Обновление статуса игры
                if self.player2_grid.GetCellValue(row, col) != '':  # Проверяем, не кликнули ли на уже открытую клетку
                    return
                if self.player2_board.check_hit(col, row):  # Проверяем, попал ли игрок в корабль противника
                    self.player2_grid.SetCellValue(row, col, 'X')  # Отображаем попадание на сетке
                    self.player2_grid.SetCellBackgroundColour(row, col, wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))  # Меняем цвет клетки на серый
                    if self.player2_board.check_win():  # Проверяем, выиграл ли игрок
                        wx.MessageBox('Игрок 1 выиграл!', 'Поздравляем')  # Выводим сообщение о победе
                        self.Close()  # Закрываем окно игры
                else:
                    self.player2_grid.SetCellValue(row, col, 'O')  # Отображаем промах на сетке
                    self.player2_grid.SetReadOnly(row, col, True)  # Блокируем клетку от дальнейших кликов
                    self.current_player = 2  # Переключаем на второго игрока
                    self.player2_grid.Disable()  # Отключаем сетку для кликов
                    self.player1_grid.Enable()  # Включаем сетку для кликов первому игроку
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.update_status_bar("Ходит игрок 2")  # Обновление статуса игры
                if self.player1_grid.GetCellValue(row, col) != '':  # Проверяем, не кликнули ли на уже открытую клетку
                    return
                if self.player1_board.check_hit(col, row):  # Проверяем, попал ли игрок в корабль противника
                    self.player1_grid.SetCellValue(row, col, 'X')  # Отображаем попадание на сетке
                    self.player1_grid.SetCellBackgroundColour(row, col, wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))  # Меняем цвет клетки на серый
                    if self.player1_board.check_win():  # Проверяем, выиграл ли игрок
                        wx.MessageBox('Игрок 2 выиграл!', 'Поздравляем')  # Выводим сообщение о победе
                        self.Close()  # Закрываем окно игры
                else:
                    self.player1_grid.SetCellValue(row, col, 'O')  # Отображаем промах на сетке
                    self.player1_grid.SetReadOnly(row, col, True)  # Блокируем клетку от дальнейших кликов
                    self.current_player = 1  # Переключаем на первого игрока
                    self.player1_grid.Disable()  # Отключаем сетку для кликов
                    self.player2_grid.Enable()  # Включаем сетку для кликов второму игроку
            self.player1_grid.Refresh()  # Обновляем сетку первого игрока для отображения изменений

    def explode_mine(self, row, col):
        # Взрываем текущую клетку
        if self.current_player == 1:  # Если текущий игрок - первый
            self.player2_board.board[row][col] = 'X'  # Помечаем клетку как подбитую на доске второго игрока
            self.player2_grid.SetCellValue(row, col, 'X')  # Отображаем подбитие на сетке второго игрока
            self.player2_grid.SetCellBackgroundColour(row, col, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный
        elif self.current_player == 2:  # Если текущий игрок - второй
            self.player1_board.board[row][col] = 'X'  # Помечаем клетку как подбитую на доске первого игрока
            self.player1_grid.SetCellValue(row, col, 'X')  # Отображаем подбитие на сетке первого игрока
            self.player1_grid.SetCellBackgroundColour(row, col, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный

        # Взрываем клетку выше, если она существует
        if row > 0:  # Проверяем, что есть клетка выше
            if self.current_player == 1:  # Если текущий игрок - первый
                self.player2_board.board[row - 1][col] = 'X'  # Помечаем клетку как подбитую на доске второго игрока
                self.player2_grid.SetCellValue(row - 1, col, 'X')  # Отображаем подбитие на сетке второго игрока
                self.player2_grid.SetCellBackgroundColour(row - 1, col, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.player1_board.board[row - 1][col] = 'X'  # Помечаем клетку как подбитую на доске первого игрока
                self.player1_grid.SetCellValue(row - 1, col, 'X')  # Отображаем подбитие на сетке первого игрока
                self.player1_grid.SetCellBackgroundColour(row - 1, col, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный
                

        # Взрываем клетку левее, если она существует
        if col > 0:  # Проверяем, что есть клетка левее
            if self.current_player == 1:  # Если текущий игрок - первый
                self.player2_board.board[row][col - 1] = 'X'  # Помечаем клетку как подбитую на доске второго игрока
                self.player2_grid.SetCellValue(row, col - 1, 'X')  # Отображаем подбитие на сетке второго игрока
                self.player2_grid.SetCellBackgroundColour(row, col - 1, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.player1_board.board[row][col - 1] = 'X'  # Помечаем клетку как подбитую на доске первого игрока
                self.player1_grid.SetCellValue(row, col - 1, 'X')  # Отображаем подбитие на сетке первого игрока
                self.player1_grid.SetCellBackgroundColour(row, col - 1, wx.Colour(255, 0, 0))  # Меняем цвет клетки на красный

        # Убираем мину из списка мин
        if self.current_player == 1:  # Если текущий игрок - первый
            if (row, col) in self.player2_board.mines:  # Проверяем, содержится ли эта клетка в списке мин второго игрока
                self.player2_board.mines.remove((row, col))  # Удаляем мину из списка мин второго игрока
        elif self.current_player == 2:  # Если текущий игрок - второй
            if (row, col) in self.player1_board.mines:  # Проверяем, содержится ли эта клетка в списке мин первого игрока
                self.player1_board.mines.remove((row, col))  # Удаляем мину из списка мин первого игрока

       
        # Обновляем сетки после взрыва мины
        self.update_grids()  # Вызываем функцию обновления сеток для отображения изменений

    def update_grids(self):
        if self.current_player == 1:  # Если текущий игрок - первый
            self.player1_text.SetLabel("Размещение кораблей (Игрок 1)")  # Обновляем текстовую метку для первого игрока
            self.update_status_bar("Размещение кораблей (Игрок 1), выберите тип корабля")  # Обновляем статус игры
            self.player2_text.SetLabel("Ожидание размещения (Игрок 2)")  # Обновляем текстовую метку для второго игрока
        elif self.current_player == 2:  # Если текущий игрок - второй
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения для второго игрока
            self.player1_text.SetLabel("Ожидание размещения (Игрок 1)")  # Обновляем текстовую метку для первого игрока
            self.update_status_bar("Размещение кораблей (Игрок 2), выберите тип корабля")  # Обновляем статус игры
            self.player2_text.SetLabel("Размещение кораблей (Игрок 2)")  # Обновляем текстовую метку для второго игрока
        if self.player1_board.remaining_ships == 0 and self.player2_board.remaining_ships == 0:
            self.finish_placement_button.Enable()  # Включаем кнопку завершения размещения, если все корабли размещены

        self.update_grid_visibility(self.player1_grid, self.player1_board)  # Обновляем видимость сетки для первого игрока
        self.update_grid_visibility(self.player2_grid, self.player2_board)  # Обновляем видимость сетки для второго игрока

    def update_grid_visibility(self, grid, board):
        for row in range(grid.GetNumberRows()):  # Итерируем по строкам сетки
            for col in range(grid.GetNumberCols()):  # Итерируем по столбцам сетки
                cell_value = board.board[row][col]  # Получаем значение клетки на доске
                if (row, col) in board.mines:
                    # Если клетка является миной, делаем её недоступной для кликов
                    grid.SetReadOnly(row, col, True)
                elif cell_value != '' and not board.visible:
                    # Если клетка не пуста и доска не видима, делаем клетку пустой и недоступной для изменений
                    grid.SetCellValue(row, col, '')
                    grid.SetReadOnly(row, col, True)
                else:
                    grid.SetReadOnly(row, col, True)  # В противном случае, делаем клетку недоступной для изменений


app = wx.App(False)  # Создаем новый экземпляр приложения
frame = BattleshipGame(None)  # Создаем главное окно игры
frame.Show(True)  # Отображаем главное окно
app.MainLoop()  # Запускаем главный цикл приложения
