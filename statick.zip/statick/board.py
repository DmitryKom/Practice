import random  # Импорт модуля random для генерации случайных чисел

class Board:
    def __init__(self):
        # Инициализация игровой доски размером 10x10 и инициализация списка кораблей
        self.size = 10
        self.board = [['' for _ in range(10)] for _ in range(10)]  # Создание пустой доски
        self.ships = {'Battleship': 4, 'Cruiser': 3, 'Destroyer': 2, 'Submarine': 1}  # Словарь типов кораблей и их размеров
        self.remaining_ships = self.size  # Количество оставшихся кораблей для размещения
        self.placing_ship = None  # Переменные для временного хранения информации о текущем размещаемом корабле
        self.placing_size = 0
        self.placing_orientation = None
        self.board_count = {ship: 0 for ship in self.ships}  # Словарь для подсчета количества размещенных кораблей каждого типа
        self.ship_counts = {'Battleship': 1, 'Cruiser': 2, 'Destroyer': 3, 'Submarine': 4}  # Максимальное количество кораблей каждого типа

    def place_ship(self, x, y):
        # Размещение корабля на указанных координатах
        if self.can_place_ship(x, y):
            self.set_ship(x, y, self.placing_size, self.placing_orientation, self.placing_ship)
            self.remaining_ships -= 1  # Уменьшение количества оставшихся кораблей
            self.board_count[self.placing_ship] += 1  # Обновление количества размещенных кораблей указанного типа
            return True
        else:
            return False

    def can_place_ship(self, x, y):
        # Проверка возможности размещения корабля на указанных координатах
        if self.placing_orientation == 'H' and x + self.placing_size > self.size:
            return False  # Если корабль выходит за границы доски по горизонтали, то размещение невозможно
        elif self.placing_orientation == 'V' and y + self.placing_size > self.size:
            return False  # Если корабль выходит за границы доски по вертикали, то размещение невозможно

        for i in range(-1, self.placing_size+1):
            for j in range(-1, 2):
                # Проверка на перекрытие с другими кораблями
                if self.placing_orientation == 'H':
                    if 0 <= y+j < self.size and 0 <= x+i < self.size and self.board[y+j][x+i] != '':
                        return False  # Если корабль перекрывается с другими кораблями, то размещение невозможно
                else:
                    if 0 <= y+i < self.size and 0 <= x+j < self.size and self.board[y+i][x+j] != '':
                        return False  # Если корабль перекрывается с другими кораблями, то размещение невозможно

        # Проверка на максимальное количество размещаемых кораблей каждого типа
        if self.placing_ship is not None:
            if self.board_count[self.placing_ship] >= self.ship_counts[self.placing_ship]:
                return False  # Если количество размещенных кораблей данного типа достигло максимума, то размещение невозможно

        return True  # Размещение возможно

    def set_ship(self, x, y, size, orientation, ship):
        # Установка корабля на доску в указанных координатах и ориентации
        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship  # Установка горизонтального корабля
            else:
                self.board[y + i][x] = ship  # Установка вертикального корабля

    def place_computer_ships(self):
        # Размещение кораблей компьютера на доске
        for ship, size in self.ships.items():
            while True:
                x, y, orientation = random.randint(0, 9), random.randint(0, 9), random.choice(['H', 'V'])
                self.placing_ship = ship
                self.placing_size = size
                self.placing_orientation = orientation
                if self.can_place_ship(x, y):
                    self.set_ship(x, y, size, orientation, ship)
                    break

    def set_ship(self, x, y, size, orientation, ship):

        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship
            else:
                self.board[y + i][x] = ship

    def check_hit(self, x, y):
        # Проверка попадания по указанным координатам
        if self.board[y][x] != '':
            self.board[y][x] = 'X'  # Помечаем попадание на доске
            return True  # Есть попадание
        return False  # Промах

    def check_win(self):
        # Проверка завершения игры
        for row in self.board:
            for cell in row:
                if cell != '' and cell != 'X':
                    return False  # Если есть незатронутые клетки, игра продолжается
        return True  # Все корабли потоплены, игра завершена
