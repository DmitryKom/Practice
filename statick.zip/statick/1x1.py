import wx  # Импортируем библиотеку wxPython для создания графического интерфейса
import wx.grid as gridlib  # Импортируем модуль для работы с сетками в wxPython
import wx.lib.dialogs  # Импортируем модуль для диалоговых окон в wxPython
import random  # Импортируем модуль для генерации случайных чисел

class Board:
    def __init__(self, size, num_ships):
        self.size = size  # Инициализируем размер доски
        self.board = [['' for _ in range(size)] for _ in range(size)]  # Создаем двумерный массив для хранения состояния клеток на доске
        self.num_ships = num_ships  # Инициализируем количество кораблей
        self.ships = {'Battleship': 4, 'Cruiser': 3, 'Destroyer': 2, 'Submarine': 1}  # Определяем типы кораблей и их размеры
        self.remaining_ships = self.num_ships  # Определяем количество оставшихся кораблей для размещения
        self.placing_ship = None  # Инициализируем переменную для текущего размещаемого корабля
        self.placing_size = 0  # Инициализируем переменную для размера текущего размещаемого корабля
        self.placing_orientation = None  # Инициализируем переменную для ориентации текущего размещаемого корабля
        self.visible = True  # Инициализируем переменную, определяющую видимость доски
        self.mines = []  # Добавленный атрибут для хранения информации о минах
        self.board_count = {ship: 0 for ship in self.ships}  # Инициализируем словарь для подсчета размещенных кораблей каждого типа
        self.ship_counts = {'Battleship': 1, 'Cruiser': 2, 'Destroyer': 3, 'Submarine': 4}  # Определяем количество кораблей каждого типа
    
    def place_mines(self, num_mines):
        for _ in range(num_mines):  # Генерируем указанное количество мин
            x, y = random.randint(0, self.size-1), random.randint(0, self.size-1)  # Генерируем случайные координаты для размещения мины
            print(x, y)  # Выводим координаты мины (для тестирования)
            self.mines.append((x, y))  # Добавляем координаты мины в список мин на доске

    def place_ship(self, x, y):
        if self.can_place_ship(x, y):  # Проверяем, можно ли разместить корабль в указанных координатах
            self.set_ship(x, y, self.placing_size, self.placing_orientation, self.placing_ship)  # Размещаем корабль на доске
            self.remaining_ships -= 1  # Уменьшаем количество оставшихся кораблей для размещения
            self.board_count[self.placing_ship] += 1  # Обновляем количество размещенных кораблей
            return True  # Возвращаем True, если корабль успешно размещен
        else:
            return False  # Возвращаем False, если корабль не может быть размещен

    def can_place_ship(self, x, y):
        # Проверяем, не выходит ли корабль за границы доски
        if self.placing_orientation == 'H' and x + self.placing_size > self.size:
            return False  # Возвращаем False, если корабль выходит за границы доски при горизонтальной ориентации
        elif self.placing_orientation == 'V' and y + self.placing_size > self.size:
            return False  # Возвращаем False, если корабль выходит за границы доски при вертикальной ориентации


        # Проверяем, не перекрывается ли корабль с другими кораблями или выходит за границы доски
        for i in range(-1, self.placing_size+1):
            for j in range(-1, 2):
                if self.placing_orientation == 'H':
                    if 0 <= y+j < self.size and 0 <= x+i < self.size and self.board[y+j][x+i] != '':
                        return False  # Возвращаем False, если корабль перекрывается с другими кораблями или выходит за границы доски при горизонтальной ориентации
                else:
                    if 0 <= y+i < self.size and 0 <= x+j < self.size and self.board[y+i][x+j] != '':
                        return False  # Возвращаем False, если корабль перекрывается с другими кораблями или выходит за границы доски при вертикальной ориентации

        # Добавляем проверку на количество размещаемых кораблей каждого типа
        if self.placing_ship is not None:
            if self.board_count[self.placing_ship] >= self.ship_counts[self.placing_ship]:
                return False  # Возвращаем False, если достигнуто максимальное количество кораблей данного типа

        return True  # Возвращаем True, если корабль может быть успешно размещен


    def set_ship(self, x, y, size, orientation, ship):
        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship  # Размещаем корабль на доске горизонтально
            else:
                self.board[y + i][x] = ship  # Размещаем корабль на доске вертикально

    def check_hit(self, x, y):
        if self.board[y][x] != '':
            if self.board[y][x] == 'X':  # Уже подбитая клетка
                return False
            self.board[y][x] = 'X'  # Помечаем как подбитую
            # Проверяем, если корабль полностью подбит, помечаем его соответственно
            ship_destroyed = True
            for row in self.board:
                for cell in row:
                    if cell == self.board[y][x]:
                        ship_destroyed = False
                        break
            if ship_destroyed:
                for row in range(len(self.board)):
                    for col in range(len(self.board[row])):
                        if self.board[row][col] == self.board[y][x]:
                            self.board[row][col] = 'X'
            return True  # Возвращаем True, если успешно подбита клетка корабля
        return False  # Возвращаем False, если клетка пуста (промах)
    
    def check_win(self):
        for row in self.board:
            for cell in row:
                if cell != '' and cell != 'X':
                    return False  # Возвращаем False, если на доске есть неразрушенные корабли
        return True  # Возвращаем True, если все корабли разрушены


    def destroyed_ships(self):
        destroyed = {ship: 0 for ship in self.ships}  # Инициализируем словарь для подсчета разрушенных кораблей каждого типа
        for row in self.board:
            for cell in row:
                if cell == 'X':  # Если клетка подбита
                    for ship in self.ships:
                        if ship in cell:  # Проверяем, к какому кораблю относится подбитая клетка
                            destroyed[ship] += 1  # Увеличиваем количество разрушенных кораблей данного типа
        return destroyed  # Возвращаем словарь с количеством разрушенных кораблей каждого типа

class BattleshipGame(wx.Frame):
    def __init__(self, parent):
        
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="Морской бой", size=wx.DefaultSize)  # Инициализируем главное окно приложения с указанием заголовка и размера

        self.panel = wx.Panel(self)  # Создаем панель для размещения виджетов

        self.status_bar = self.CreateStatusBar()  # Создание статус-бара
        self.board_size = 10  # Получаем размер доски от пользователя

        self.num_ships = 10  # Получаем количество кораблей от пользователя
        self.player1_board = Board(self.board_size, self.num_ships)  # Создаем игровую доску для первого игрока
        self.player2_board = Board(self.board_size, self.num_ships)  # Создаем игровую доску для второго игрока
        self.player1_grid = self.create_grid(self.panel, self.player1_board)  # Создаем сетку для отображения игровой доски первого игрока
        self.player2_grid = self.create_grid(self.panel, self.player2_board)  # Создаем сетку для отображения игровой доски второго игрока
        self.player1_grid.Disable()  # Отключаем сетку для первого игрока
        self.player2_grid.Disable()  # Отключаем сетку для второго игрока
        self.current_player = 1  # Устанавливаем текущего игрока

        self.player1_text = wx.StaticText(self.panel, label="")  # Создаем статический текст для первого игрока
        self.player2_text = wx.StaticText(self.panel, label="")  # Создаем статический текст для второго игрока

        self.side_panel = wx.Panel(self.panel)  # Создаем боковую панель для размещения виджетов
        self.side_sizer = wx.BoxSizer(wx.VERTICAL)  # Создаем вертикальный сизер для боковой панели
        self.side_panel.SetSizer(self.side_sizer)  # Устанавливаем сизер для боковой панели

        self.finish_placement_button = wx.Button(self.side_panel, label="Завершить размещение")  # Создаем кнопку для завершения размещения кораблей
        self.finish_placement_button.Disable()  # Отключаем кнопку
        self.start_game_button = wx.Button(self.side_panel, label="Начать игру")  # Создаем кнопку для начала игры
        self.start_game_button.Disable()  # Отключаем кнопку
        self.ship_choice = wx.Choice(self.side_panel, choices=list(self.player1_board.ships.keys()))  # Создаем выпадающий список для выбора типа корабля
        self.orientation_checkbox = wx.CheckBox(self.side_panel, label="Горизонтально")  # Создаем чекбокс для выбора ориентации корабля
        self.side_sizer.Add(self.ship_choice, 0, wx.ALL, 5)  # Добавляем выпадающий список выбора типа корабля на боковую панель
        self.side_sizer.Add(self.orientation_checkbox, 0, wx.ALL, 5)  # Добавляем чекбокс выбора ориентации корабля на боковую панель
        self.side_sizer.Add(self.finish_placement_button, 2, wx.ALL, 5)  # Добавляем кнопку завершения размещения на боковую панель с относительным размером 2
        self.side_sizer.Add(self.start_game_button, 0, wx.ALL, 5)  # Добавляем кнопку начала игры на боковую панель

        sizer = wx.BoxSizer(wx.VERTICAL)  # Создаем вертикальный сизер для компоновки виджетов на основной панели
        sizer.Add(self.player1_text, 0, wx.EXPAND)  # Добавляем статический текст для первого игрока на основную панель
        sizer.Add(self.player1_grid, 1, wx.EXPAND)  # Добавляем сетку для отображения игровой доски первого игрока на основную панель с расширением по вертикали
        sizer.Add(self.side_panel, 0, wx.EXPAND)  # Добавляем боковую панель на основную панель
        sizer.Add(self.player2_text, 0, wx.EXPAND)  # Добавляем статический текст для второго игрока на основную панель
        sizer.Add(self.player2_grid, 1, wx.EXPAND)  # Добавляем сетку для отображения игровой доски второго игрока на основную панель с расширением по вертикали
        self.finish_placement_button.SetMinSize((200, 30))  # Устанавливаем минимальный размер кнопки завершения размещения
        self.panel.SetSizerAndFit(sizer)  # Устанавливаем сизер для основной панели и автоматически подгоняем размер
        self.Fit()  # Подгоняем размер окна под размер содержимого

        self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, lambda event: self.on_cell_click(event, self.player1_grid, self.player2_grid))  # Привязываем обработчик события клика на клетку сетки для первого игрока
        self.finish_placement_button.Bind(wx.EVT_BUTTON, self.on_finish_placement)  # Привязываем обработчик кнопки завершения размещения
        self.start_game_button.Bind(wx.EVT_BUTTON, self.on_start_game)  # Привязываем обработчик кнопки начала игры
        self.ship_choice.Bind(wx.EVT_CHOICE, self.on_ship_choice)  # Привязываем обработчик выбора типа корабля
        self.orientation_checkbox.Bind(wx.EVT_CHECKBOX, self.on_orientation_checkbox)  # Привязываем обработчик чекбокса выбора ориентации корабля
        self.update_grids()  # Обновляем сетки

        self.game_started = False  # Устанавливаем флаг начала игры в False
    def update_status_bar(self, message):
        self.status_bar.SetStatusText(message)  # Обновляем текст в статус-баре

    def create_grid(self, parent, board):
        # Создаем сетку для отображения игровой доски
        grid = gridlib.Grid(parent)
        grid.CreateGrid(self.board_size, self.board_size)  # Устанавливаем размер сетки

        # Устанавливаем метки строк и столбцов
        for i in range(self.board_size):
            grid.SetRowLabelValue(i, str(i+1))
            grid.SetColLabelValue(i, chr(65+i))

        grid.AutoSizeColumns(False)  # Автоматически подгоняем размер столбцов
        # Устанавливаем размеры столбцов и строк
        for col in range(self.board_size):
            grid.SetColSize(col, 30)
            grid.SetRowSize(col, 30)
        grid.EnableEditing(False)  # Отключить редактирование ячеек
        grid.EnableDragGridSize(False)  # Отключить изменение размеров сетки методом перетаскивания
        grid.EnableDragColMove(False)  # Отключить перетаскивание столбцов
        grid.EnableDragColSize(False)  # Отключить изменение размеров столбцов методом перетаскивания
        grid.EnableDragRowSize(False)  # Отключить изменение размеров строк методом перетаскивания
        grid.EnableDragGridSize(False)
        grid.DeselectRow(False)
        grid.DeselectCol(False)
        
        return grid  # Возвращаем созданную сетку

    def on_orientation_checkbox(self, event):
        # Обработчик события изменения состояния чекбокса ориентации корабля
        # Устанавливаем ориентацию размещения кораблей в соответствии с выбором пользователя
        self.player1_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'

    def on_cell_click(self, event, grid1, grid2):
        # Обработчик события клика по клетке сетки
        if not self.player1_board.remaining_ships > 1:
            self.finish_placement_button.Enable()  # Включаем кнопку завершения размещения, если корабли размещены

        # Проверяем, что игра не началась и текущий игрок - первый, и остались неразмещенные корабли
        if not self.game_started and self.current_player == 1 and self.player1_board.remaining_ships > 0:
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика
            if self.player1_board.place_ship(col, row):  # Пытаемся разместить корабль
                self.update_grids()  # Обновляем сетки
                ship_size = self.player1_board.placing_size  # Получаем размер размещаемого корабля
                # Отображаем размещаемый корабль на сетке
                self.player1_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'
                if self.player1_board.placing_orientation == 'H':
                    for i in range(ship_size):
                        self.player1_grid.SetCellBackgroundColour(row, col + i, wx.BLUE)
                        self.player1_grid.Refresh()
                else:
                    for i in range(ship_size):
                        self.player1_grid.SetCellBackgroundColour(row + i, col, wx.BLUE)
                        self.player1_grid.Refresh()

            if self.player1_board.remaining_ships < 1:
                # Если все корабли размещены, отображаем их на сетке и включаем кнопку завершения размещения
                self.finish_placement_button.Enable()
                for row in range(grid1.GetNumberRows()):
                    self.player1_grid.Refresh()
                    for col in range(grid1.GetNumberCols()):
                        self.player1_grid.SetCellBackgroundColour(row, col, wx.WHITE)
                        self.player1_grid.Refresh()

        # Проверяем, что игра не началась и текущий игрок - второй, и остались неразмещенные корабли
        elif not self.game_started and self.current_player == 2 and self.player2_board.remaining_ships > 0:
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика
            if self.player2_board.place_ship(col, row):  # Пытаемся разместить корабль
                self.update_grids()  # Обновляем сетки
                ship_size = self.player2_board.placing_size  # Получаем размер размещаемого корабля
                # Отображаем размещаемый корабль на сетке
                self.player2_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'
                if self.player2_board.placing_orientation == 'H':
                    for i in range(ship_size):
                        self.player2_grid.SetCellBackgroundColour(row, col + i, wx.BLUE)
                        self.player2_grid.Refresh()
                else:
                    for i in range(ship_size):
                        self.player2_grid.SetCellBackgroundColour(row + i, col, wx.BLUE)
                        self.player2_grid.Refresh()
            if self.player2_board.remaining_ships < 1:
                # Если все корабли размещены, отображаем их на сетке и включаем кнопку завершения размещения
                self.finish_placement_button.Enable()
                for row in range(grid2.GetNumberRows()):
                    self.player2_grid.Refresh()
                    for col in range(grid2.GetNumberCols()):
                        self.player2_grid.SetCellBackgroundColour(row, col, wx.WHITE)
                        self.player2_grid.Refresh()
                self.update_grids()

    def on_finish_placement(self, event):
        # Обработчик события завершения размещения кораблей
        if not self.game_started:  # Проверяем, что игра еще не началась
            self.player1_board.visible = False  # Скрываем доски игроков
            self.player2_board.visible = False
            if self.current_player == 1:  # Если текущий игрок - первый
                self.current_player = 2  # Переключаем на второго игрока
                self.finish_placement_button.SetLabel("Завершить размещение (Игрок 2)")  # Изменяем надпись на кнопке для второго игрока
                self.update_grids()  # Обновляем сетки
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.start_game_button.Enable()  # Включаем кнопку начала игры

    def on_start_game(self, event):
        # Обработчик события начала игры
        if not self.game_started:  # Проверяем, что игра еще не началась
            self.game_started = True  # Устанавливаем флаг начала игры в True
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения
            self.start_game_button.Disable()  # Отключаем кнопку начала игры
            self.player1_grid.Enable()
            self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click_game)  # Привязываем обработчик клика на клетку для игрового режима
            self.update_status_bar("Игра началась")  # Обновляем статус игры

    def on_ship_choice(self, event):
        # Обработчик выбора типа корабля
        ship_name = self.ship_choice.GetString(self.ship_choice.GetSelection())  # Получаем выбранный тип корабля
        if self.current_player == 1:  # Если текущий игрок - первый
            if self.player1_board.board_count[ship_name] >= self.player1_board.ships[ship_name]:
                # Проверяем, что не превышено максимальное количество кораблей данного типа
                wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
                return
            self.player1_grid.Enable()  # Включаем сетку для размещения корабля
            self.player1_board.placing_ship = ship_name  # Устанавливаем тип размещаемого корабля
            self.player1_board.placing_size = self.player1_board.ships[ship_name]  # Устанавливаем размер корабля
        elif self.current_player == 2:  # Если текущий игрок - второй
            if self.player2_board.board_count[ship_name] >= self.player2_board.ships[ship_name]:
                # Проверяем, что не превышено максимальное количество кораблей данного типа
                wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
                return
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения для второго игрока
            self.player1_grid.Disable()
            self.player2_grid.Enable()  # Включаем сетку для размещения корабля
            self.player2_board.placing_ship = ship_name  # Устанавливаем тип размещаемого корабля
            self.player2_board.placing_size = self.player2_board.ships[ship_name]  # Устанавливаем размер корабля

    def on_cell_click_game(self, event):
        # Обработчик события клика на клетку во время игрового режима
        if self.game_started:  # Проверяем, что игра началась
            row, col = event.GetRow(), event.GetCol()  # Получаем координаты клика

            if self.current_player == 1:  # Если текущий игрок - первый
                self.update_status_bar("Ходит игрок 1")  # Обновление статуса игры
                if self.player2_grid.GetCellValue(row, col) != '':  # Проверяем, не кликнули ли на уже открытую клетку
                    return
                if self.player2_board.check_hit(col, row):  # Проверяем, попал ли игрок в корабль противника
                    self.player2_grid.SetCellValue(row, col, 'X')  # Отображаем попадание на сетке
                    self.player2_grid.SetCellBackgroundColour(row, col, wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))  # Меняем цвет клетки на серый
                    if self.player2_board.check_win():  # Проверяем, выиграл ли игрок
                        wx.MessageBox('Игрок 1 выиграл!', 'Поздравляем')  # Выводим сообщение о победе
                        self.Close()  # Закрываем окно игрыR
                else:
                    self.player2_grid.SetCellValue(row, col, 'O')  # Отображаем промах на сетке
                    self.player2_grid.SetReadOnly(row, col, True)  # Блокируем клетку от дальнейших кликов
                    self.current_player = 2  # Переключаем на второго игрока
                    self.player2_grid.Disable()  # Отключаем сетку для кликов
                    self.player1_grid.Enable()  # Включаем сетку для кликов первому игроку
            elif self.current_player == 2:  # Если текущий игрок - второй
                self.update_status_bar("Ходит игрок 2")  # Обновление статуса игры
                if self.player1_grid.GetCellValue(row, col) != '':  # Проверяем, не кликнули ли на уже открытую клетку
                    return
                if self.player1_board.check_hit(col, row):  # Проверяем, попал ли игрок в корабль противника
                    self.player1_grid.SetCellValue(row, col, 'X')  # Отображаем попадание на сетке
                    self.player1_grid.SetCellBackgroundColour(row, col, wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))  # Меняем цвет клетки на серый
                    if self.player1_board.check_win():  # Проверяем, выиграл ли игрок
                        wx.MessageBox('Игрок 2 выиграл!', 'Поздравляем')  # Выводим сообщение о победе
                        self.Close()  # Закрываем окно игры
                else:
                    self.player1_grid.SetCellValue(row, col, 'O')  # Отображаем промах на сетке
                    self.player1_grid.SetReadOnly(row, col, True)  # Блокируем клетку от дальнейших кликов
                    self.current_player = 1  # Переключаем на первого игрока
                    self.player1_grid.Disable()  # Отключаем сетку для кликов
                    self.player2_grid.Enable()  # Включаем сетку для кликов второму игроку
            self.player1_grid.Refresh()  # Обновляем сетку первого игрока для отображения изменений

    def update_grids(self):
        if self.current_player == 1:  # Если текущий игрок - первый
            self.player1_text.SetLabel("Размещение кораблей (Игрок 1)")  # Обновляем текстовую метку для первого игрока
            self.update_status_bar("Размещение кораблей (Игрок 1), выберите тип корабля")  # Обновляем статус игры
            self.player2_text.SetLabel("Ожидание размещения (Игрок 2)")  # Обновляем текстовую метку для второго игрока
        elif self.current_player == 2:  # Если текущий игрок - второй
            self.finish_placement_button.Disable()  # Отключаем кнопку завершения размещения для второго игрока
            self.player1_text.SetLabel("Ожидание размещения (Игрок 1)")  # Обновляем текстовую метку для первого игрока
            self.update_status_bar("Размещение кораблей (Игрок 2), выберите тип корабля")  # Обновляем статус игры
            self.player2_text.SetLabel("Размещение кораблей (Игрок 2)")  # Обновляем текстовую метку для второго игрока
        if self.player1_board.remaining_ships == 0 and self.player2_board.remaining_ships == 0:
            self.finish_placement_button.Enable()  # Включаем кнопку завершения размещения, если все корабли размещены

        self.update_grid_visibility(self.player1_grid, self.player1_board)  # Обновляем видимость сетки для первого игрока
        self.update_grid_visibility(self.player2_grid, self.player2_board)  # Обновляем видимость сетки для второго игрока

    def update_grid_visibility(self, grid, board):
        for row in range(grid.GetNumberRows()):  # Итерируем по строкам сетки
            for col in range(grid.GetNumberCols()):  # Итерируем по столбцам сетки
                cell_value = board.board[row][col]  # Получаем значение клетки на доске
                if (row, col) in board.mines:
                    # Если клетка является миной, делаем её недоступной для кликов
                    grid.SetReadOnly(row, col, True)
                elif cell_value != '' and not board.visible:
                    # Если клетка не пуста и доска не видима, делаем клетку пустой и недоступной для изменений
                    grid.SetCellValue(row, col, '')
                    grid.SetReadOnly(row, col, True)
                else:
                    grid.SetReadOnly(row, col, True)  # В противном случае, делаем клетку недоступной для изменений


app = wx.App(False)  # Создаем новый экземпляр приложения
frame = BattleshipGame(None)  # Создаем главное окно игры
frame.Show(True)  # Отображаем главное окно
app.MainLoop()  # Запускаем главный цикл приложения
