import wx
import os
import subprocess
import wx.lib.agw.gradientbutton as GB

class SeaBattlePanel(wx.Panel):
    def __init__(self, parent):
        super(SeaBattlePanel, self).__init__(parent)

        self.vbox = wx.BoxSizer(wx.VERTICAL)

        self.mode_buttons = []

        modes = [
            "Игра против компьютера (корабли расставлены)",
            "Игра против компьютера (корабли расставляются случайным образом)",
            "Игра с другом",
            "Расширенный режим"
        ]

        for mode in modes:
            btn = wx.Button(self, label=mode, size=(-1, 30))
            self.vbox.Add(btn, flag=wx.EXPAND | wx.ALL, border=5)
            btn.Bind(wx.EVT_BUTTON, self.OnModeButtonClick)
            btn.Hide()
            self.mode_buttons.append(btn)

        self.mode_button = wx.Button(self, label='Выбор режима')
        self.mode_button.Bind(wx.EVT_BUTTON, self.OnModeButtonClick)
        self.vbox.Add(self.mode_button, flag=wx.EXPAND | wx.ALL, border=10)

        self.exit_button = wx.Button(self, label='Выйти')
        self.exit_button.Bind(wx.EVT_BUTTON, self.OnExitButtonClick)
        self.vbox.Add(self.exit_button, flag=wx.EXPAND | wx.ALL, border=10)

        self.SetSizer(self.vbox)

    def OnModeButtonClick(self, event):
        if event.GetEventObject().GetLabel() == "Игра против компьютера (корабли расставлены)":
            self.statik_bot()  # Отобразить сетку игры
        elif event.GetEventObject().GetLabel() == "Игра против компьютера (корабли расставляются случайным образом)":
            self.random_bot()
        elif event.GetEventObject().GetLabel() == "Игра с другом":
            self.one_x_one()
        elif event.GetEventObject().GetLabel() == "Расширенный режим":
            self.more_game()
        else:
            self.mode_button.Hide()

            for btn in self.mode_buttons:
                btn.Show()

            self.Layout()

    def OnExitButtonClick(self, event):
        self.GetParent().Close()
    def more_game(self):
    # Очистить панель перед отображением сетки игры
        self.GetParent().Close()

        # Путь к вашему модулю
        module_path = 'D:\\Дима Основное\\Загрузки\\statick\\more_game.py'

        # Проверяем, существует ли файл
        if os.path.exists(module_path):
            # Запускаем модуль с помощью subprocess
            subprocess.Popen(['python', module_path])
        else:
            print(f"Модуль {module_path} не найден.")

    def one_x_one(self):
    # Очистить панель перед отображением сетки игры
        self.GetParent().Close()

        # Путь к вашему модулю
        module_path = 'D:\\Дима Основное\\Загрузки\\statick\\1x1.py'

        # Проверяем, существует ли файл
        if os.path.exists(module_path):
            # Запускаем модуль с помощью subprocess
            subprocess.Popen(['python', module_path])
        else:
            print(f"Модуль {module_path} не найден.")

    def random_bot(self):
    # Очистить панель перед отображением сетки игры
        self.GetParent().Close()

        # Путь к вашему модулю
        module_path = 'D:\\Дима Основное\\Загрузки\\statick\\random_bot.py'

        # Проверяем, существует ли файл
        if os.path.exists(module_path):
            # Запускаем модуль с помощью subprocess
            subprocess.Popen(['python', module_path])
        else:
            print(f"Модуль {module_path} не найден.")


    def statik_bot(self):
    # Очистить панель перед отображением сетки игры
        self.GetParent().Close()

        # Путь к вашему модулю
        module_path = 'D:\\Дима Основное\\Загрузки\\statick\\statik_bot.py'

        # Проверяем, существует ли файл
        if os.path.exists(module_path):
            # Запускаем модуль с помощью subprocess
            subprocess.Popen(['python', module_path])
        else:
            print(f"Модуль {module_path} не найден.")


class SeaBattleFrame(wx.Frame):
    def __init__(self, parent, title):
        super(SeaBattleFrame, self).__init__(parent, title=title, size=(400, 400))

        self.InitUI()

    def InitUI(self):
        menubar = wx.MenuBar()
        fileMenu = wx.Menu()
        aboutMenu = wx.Menu()

        fileMenu.Append(wx.ID_ANY, 'В меню')
        fileMenu.Append(wx.ID_ANY, 'Выбор режима', 'Выбор режима')
        fileMenu.Append(wx.ID_EXIT, 'Выйти')

        aboutMenu.Append(wx.ID_ANY, 'Информация')

        menubar.Append(fileMenu, 'Menu')
        menubar.Append(aboutMenu, 'About')
        self.SetMenuBar(menubar)

        self.panel = SeaBattlePanel(self)


app = wx.App(False)
frame = SeaBattleFrame(None, title="Sea Battle")
frame.Show()
app.MainLoop()
