import wx
import wx.grid as gridlib

from battleship_game import BattleshipGame

app = wx.App(False)
frame = BattleshipGame(None)
frame.Show(True)
app.MainLoop()