import wx
from sea_battle_panel import SeaBattlePanel


if __name__ == '__main__':
    app = SeaBattlePanel()
    