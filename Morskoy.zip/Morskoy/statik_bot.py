import wx  
import wx.grid as gridlib  
import random  

class Board:
    def __init__(self):
        
        self.size = 10
        self.board = [['' for _ in range(10)] for _ in range(10)]  
        self.ships = {'Battleship': 4, 'Cruiser': 3, 'Destroyer': 2, 'Submarine': 1}  
        self.remaining_ships = self.size  
        self.placing_ship = None  
        self.placing_size = 0
        self.placing_orientation = None
        self.board_count = {ship: 0 for ship in self.ships}  
        self.ship_counts = {'Battleship': 1, 'Cruiser': 2, 'Destroyer': 3, 'Submarine': 4}  

    def place_ship(self, x, y):
        if self.can_place_ship(x, y):
            self.set_ship(x, y, self.placing_size, self.placing_orientation, self.placing_ship)
            self.remaining_ships -= 1  
            self.board_count[self.placing_ship] += 1 
            return True
        else:
            return False

    def can_place_ship(self, x, y):
 
        if self.placing_orientation == 'H' and x + self.placing_size > self.size:
            return False  
        elif self.placing_orientation == 'V' and y + self.placing_size > self.size:
            return False 

        for i in range(-1, self.placing_size+1):
            for j in range(-1, 2):
               
                if self.placing_orientation == 'H':
                    if 0 <= y+j < self.size and 0 <= x+i < self.size and self.board[y+j][x+i] != '':
                        return False  
                else:
                    if 0 <= y+i < self.size and 0 <= x+j < self.size and self.board[y+i][x+j] != '':
                        return False  


        if self.placing_ship is not None:
            if self.board_count[self.placing_ship] >= self.ship_counts[self.placing_ship]:
                return False  

        return True

    def set_ship(self, x, y, size, orientation, ship):

        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship
            else:
                self.board[y + i][x] = ship

    def set_ship(self, x, y, size, orientation, ship):

        for i in range(size):
            if orientation == 'H':
                self.board[y][x + i] = ship
            else:
                self.board[y + i][x] = ship

    def check_hit(self, x, y):

        if self.board[y][x] != '':
            self.board[y][x] = 'X'
            return True
        return False

    def check_win(self):

        for row in self.board:
            for cell in row:
                if cell != '' and cell != 'X':
                    return False
        return True

class BattleshipGame(wx.Frame):
    def __init__(self, parent):

        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="Морской бой")

        self.panel = wx.Panel(self)
        self.player_board = Board()
        self.computer_board = Board()
        self.player_grid = self.create_grid(self.panel, self.player_board) 
        self.computer_grid = self.create_grid(self.panel, self.computer_board)
        

        self.side_panel = wx.Panel(self.panel)
        self.side_sizer = wx.BoxSizer(wx.VERTICAL)
        self.side_panel.SetSizer(self.side_sizer)


        self.ship_choice = wx.Choice(self.side_panel, choices=list(self.player_board.ships.keys()))
        self.orientation_checkbox = wx.CheckBox(self.side_panel, label="Горизонтально")
        self.start_game_button = wx.Button(self.side_panel, label="Начать игру")


        self.side_sizer.Add(self.ship_choice, 0, wx.ALL, 5)
        self.side_sizer.Add(self.orientation_checkbox, 0, wx.ALL, 5)
        self.side_sizer.Add(self.start_game_button, 0, wx.ALL, 5)


        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.player_grid, 1, wx.EXPAND)
        sizer.Add(self.side_panel, 0, wx.EXPAND)
        sizer.Add(self.computer_grid, 1, wx.EXPAND)

        self.panel.SetSizerAndFit(sizer)
        self.Fit()
        self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click)
        self.ship_choice.Bind(wx.EVT_CHOICE, self.on_ship_choice)
        self.orientation_checkbox.Bind(wx.EVT_CHECKBOX, self.on_orientation_checkbox)
        self.start_game_button.Bind(wx.EVT_BUTTON, self.on_start_game)
        self.start_game_button.Disable()
        
        self.update_grids()

        self.computer_board.set_ship(0, 0, 4, 'H', 'Battleship')
        self.computer_board.set_ship(1, 0, 3, 'H', 'Cruiser')
        self.computer_board.set_ship(2, 0, 2, 'H', 'Destroyer')
        self.computer_board.set_ship(3, 0, 1, 'H', 'Submarine')
        
        self.last_hit = None 
        self.game_started = False 

    def create_grid(self, parent, board):

        grid = gridlib.Grid(parent)
        grid.CreateGrid(10, 10)

        for i in range(10):
            grid.SetRowLabelValue(i, str(i+1))
            grid.SetColLabelValue(i, chr(65+i))

        grid.AutoSizeColumns(False)
        for col in range(10):
            grid.SetColSize(col, 30)
            grid.SetRowSize(col, 30)

        return grid
    def on_cell_click(self, event):

        if not self.player_board.remaining_ships > 1:
           self.start_game_button.Enable()

        if not self.game_started and self.player_board.remaining_ships > 0:
            row, col = event.GetRow(), event.GetCol()
            if self.player_board.place_ship(col, row):
                self.update_grids()

    def on_cell_click_player(self, event):

        row, col = event.GetRow(), event.GetCol()
        if self.computer_grid.GetCellValue(row, col) != '':
            return 
        if self.computer_board.check_hit(col, row):
            self.computer_grid.SetCellValue(row, col, 'X')
            if self.computer_board.check_win():
                wx.MessageBox('Вы выиграли!', 'Поздравляем')
                self.Close()
        else:
            self.computer_grid.SetCellValue(row, col, 'O') 
        self.computer_move() 
        self.update_grids() 

    def computer_move(self):

        while True:
            if self.last_hit is not None:

                directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
                random.shuffle(directions)
                for dx, dy in directions:
                    row, col = self.last_hit[0] + dx, self.last_hit[1] + dy
                    if 0 <= row < 10 and 0 <= col < 10 and self.player_grid.GetCellValue(row, col) == '':
                        break
                else:
                    self.last_hit = None 
            if self.last_hit is None:
                row, col = random.randint(0, 9), random.randint(0, 9)
            if self.player_grid.GetCellValue(row, col) != '':
                continue 
            if self.player_board.check_hit(col, row):
                self.player_grid.SetCellValue(row, col, 'X') 
                self.last_hit = (row, col)
                if self.player_board.check_win():
                    wx.MessageBox('Компьютер выиграл!', 'О нет!')
                    self.Close()
                break
            else:
                self.player_grid.SetCellValue(row, col, 'O')
                break
        self.update_grids()

    def update_grids(self):

        for i in range(10):
            for j in range(10):
                if self.player_board.board[i][j] != '':
                    self.player_grid.SetCellBackgroundColour(i, j, wx.BLUE)
        self.player_grid.Refresh()


    def on_ship_choice(self, event):
        ship_name = self.ship_choice.GetString(self.ship_choice.GetSelection())
        
        if self.player_board.board_count[ship_name] >= self.player_board.ships[ship_name]:
            wx.MessageBox(f"Вы уже разместили максимальное количество кораблей типа {ship_name}.", "Ошибка", wx.OK | wx.ICON_ERROR)
            return
        self.player_grid.Enable()
        self.player_board.placing_ship = ship_name
        self.player_board.placing_size = self.player_board.ships[ship_name]
        

    def on_orientation_checkbox(self, event):

        self.player_board.placing_orientation = 'H' if self.orientation_checkbox.IsChecked() else 'V'

    def on_start_game(self, event):

        if self.player_board.remaining_ships == 0:
            self.game_started = True
            self.update_grids()
            self.computer_move()
            self.Bind(gridlib.EVT_GRID_CELL_LEFT_CLICK, self.on_cell_click_player, self.computer_grid)
            self.start_game_button.Disable()
 
app = wx.App(False)
frame = BattleshipGame(None)
frame.Show(True)
app.MainLoop()
